<template>
  <div id="footer" class="mt-5">
    <footer
      class="page-footer bg-dark text-white border pt-4"
    >
      <div class="container-fluid text-center text-md-left">
        <div class="row">
          <div class="col-md-6">
            <h3 class="title mb-3">MisionTic 2022</h3>
            <p class="pr-5">
              Este sitio web ha sido creado en el marco del segundo Sprint del
              ciclo tres del Curso de Programación MinTIC 2022. El enlace al
              repositorio de GitHub de esta pagina web está
              <a class="text-white" href="https://github.com/Bhrqz/semana-2-125"
                >aquí</a
              >
            </p>
          </div>
          <div class="col-md-6">
            <h4>Ivan Camilo Aldana</h4>
            <p>ic.aldanagallego@gmail.com</p>
            <h4>Jose Bohórquez</h4>
            <p>josebchrist@hotmail.com</p>
            <h4>Eduardo Alejandro Gallo R.</h4>
            <p>eduaralejo@gmail.com</p>
          </div>
        </div>
      </div>
      <!-- Copyright -->
    <div class="footer-copyright text-center py-1 bg-secondary">© 2020 Copyright: JEI
    </div>
    <!-- Copyright -->
    </footer>
  </div>
</template>

<script>
export default {
  name: "FooterSection",
};
</script>